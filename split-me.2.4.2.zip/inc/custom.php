<?php
/**
 * Your custom functions
 *
 * Do not add your custom functions in functions.php.
 * Add them in this file instead :)
 *
 * @package Split Me
 * @since Split Me 1.0.0
 */

function your_function_name() {
    // Do something
}
// Your hook here if needed
